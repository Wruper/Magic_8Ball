# The "MAGIC" 8 Ball

The "MAGIC" 8 Ball is an online fortune telling website.

## Description

*User side*
The user is able to:

*  use the site to recieve answers to any YES/NO questions.

*Admin side*
The admin is able to:

*  use the 8 ball

*  using his username and password log in into the admin page

*  be able to delete an answer by inputting the desired answer

*  be able to upload a new answer, that the 8 ball can use.


## Resources

*  Express

*  react

*  react-toastify

*  SASS