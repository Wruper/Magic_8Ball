const answers = [
'As I see it, yes.',
 'Ask again later.',
 'Better not tell you now.',
  'Cannot predict now',
  'Concentrate and ask again.',
'Don’t count on it.',
 'It is certain.',
  'Most likely.',
 'My reply is no. ',
  'Outlook not so good.',
 'You may rely on it.',
 'Yes – definitely.',
 'Very doubtful.',
  'Without a doubt.',
]
module.exports.answers = answers;